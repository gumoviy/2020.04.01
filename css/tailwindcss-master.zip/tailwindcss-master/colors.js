module.exports = require('./lib/public/colors').default
