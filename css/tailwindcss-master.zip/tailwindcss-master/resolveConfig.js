module.exports = require('./lib/public/resolve-config').default
