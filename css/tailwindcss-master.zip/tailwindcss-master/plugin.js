module.exports = require('./lib/public/create-plugin').default
