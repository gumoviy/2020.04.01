module.exports = require('./lib/public/default-config').default
