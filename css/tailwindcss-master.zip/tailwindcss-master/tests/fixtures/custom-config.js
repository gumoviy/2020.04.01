module.exports = {
  content: [{ raw: '<div class="mobile:font-bold"></div>' }],
  theme: {
    screens: {
      mobile: '400px',
    },
  },
}
