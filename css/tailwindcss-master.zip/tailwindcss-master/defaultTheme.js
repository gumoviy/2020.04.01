module.exports = require('./lib/public/default-theme').default
